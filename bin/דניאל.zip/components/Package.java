package components;

import java.awt.Color;
import java.awt.Graphics;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;


import program.PostSystemPanel;


public abstract class Package
{
	private static int countID=1000;
	final private int packageID;
	private Priority priority;
	private Status status;
	private Address senderAddress;
	private Address destinationAddress;
	private ArrayList<Tracking> tracking = new ArrayList<Tracking>();
	private Branch branch = null;
	private Point sendPoint;
	private Point destPoint;
	private Point bInPoint;
	private Point bOutPoint;
	private PropertyChangeSupport support;
	private int CustId;

	public Package(Priority priority, Address senderAddress,Address destinationAdress) {
		support = new PropertyChangeSupport(this);
		packageID = countID++;
		this.priority=priority;
		this.status=Status.CREATION;
		this.senderAddress=senderAddress;
		this.destinationAddress=destinationAdress;
		addPropertyChangeListener(MainOffice.getInstance(countID, countID, null, packageID));
		addTracking(new Tracking(MainOffice.getClock(), getBranch(), status));

	}	
	
	public Package(Package P)
	{
		this.bInPoint = new Point(P.bInPoint);
		this.bOutPoint = new Point(P.bOutPoint);
		this.sendPoint = new Point(P.sendPoint);
		this.destPoint = new Point(P.destPoint);
		this.priority = P.priority;
		this.packageID = P.packageID;
		this.branch = new Branch(P.branch);
		this.status = P.status;
		this.destinationAddress = new Address(P.destinationAddress);
		this.senderAddress =  new Address(P.senderAddress);
		this.tracking = new ArrayList<Tracking>(P.tracking);
		
	}

	public void setBranch(Branch branch) { 
		this.branch = branch;
	}

	public Branch getBranch() {
		return this.branch;
	}

	public Priority getPriority() {
		return priority;
	}


	public void setPriority(Priority priority) {
		this.priority = priority;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) 
	{
		this.status = status;	
	}


	public int getPackageID() { 
		return packageID;
	}



	public Address getSenderAddress() {
		return senderAddress;
	}


	public void setSenderAddress(Address senderAddress) {
		this.senderAddress = senderAddress;
	}


	public Address getDestinationAddress() {
		return destinationAddress;
	}


	public void setDestinationAddress(Address destinationAdress) {
		this.destinationAddress = destinationAdress;
	}


	public void addTracking(Node node, Status status) {
		tracking.add(new Tracking(MainOffice.getClock(), node, status));
		String line = "PackageID: "+packageID+" ,"+status + " Customer num: " + this.CustId;
		support.firePropertyChange(line, this, line);

	}


	public void addTracking(Tracking t) {
		tracking.add(t);
		String line = "PackageID: "+packageID+" ,"+t.toString() + " Customer num: " + this.CustId;
		support.firePropertyChange(line, this, line);
	}


	public ArrayList<Tracking> getTracking() {
		return tracking;
	}


	public void printTracking() {
		for (Tracking t: tracking)
			System.out.println(t);
	}


	@Override
	public String toString() {
		return "packageID=" + packageID + ", priority=" + priority + ", status=" + status + ", startTime="
				+ ", senderAddress=" + senderAddress + ", destinationAddress=" + destinationAddress;
	}

	public Point getSendPoint() {
		return sendPoint;
	}

	public Point getDestPoint() {
		return destPoint;
	}

	public Point getBInPoint() {
		return bInPoint;
	}

	public Point getBOutPoint() {
		return bOutPoint;
	}


	public void paintComponent(Graphics g, int x, int offset) {
		if (status==Status.CREATION || (branch==null && status == Status.COLLECTION))
			g.setColor(new Color(204,0,0));
		else
			g.setColor(new Color(255,180,180));
		g.fillOval(x, 20, 30, 30);

		if (status==Status.DELIVERED)
			g.setColor(new Color(204,0,0));
		else
			g.setColor(new Color(255,180,180));
		g.fillOval(x, 583, 30, 30);


		if (branch!=null) {
			g.setColor(Color.BLUE);
			g.drawLine(x+15,50,40,100+offset*this.senderAddress.getZip());
			sendPoint = new Point(x+15,50);
			bInPoint = new Point(40, 100+offset*this.senderAddress.getZip());
			g.drawLine(x+15,583,40,130+offset*this.destinationAddress.getZip());
			destPoint = new Point(x+15,583);
			bOutPoint = new Point(40,130+offset*this.destinationAddress.getZip());

		}
		else {
			g.setColor(Color.RED);
			g.drawLine(x+15,50,x+15,583);
			g.drawLine(x+15,50,1140, 216);
			sendPoint = new Point(x+15,50);
			destPoint = new Point(x+15,583);

		}
	}


	public String GetTrackingToString()
	{
		return MainOffice.getPackages().indexOf(this) + 1 + ") " +  "Package: " + packageID + " Status: " + status;
	}


	public void addPropertyChangeListener(PropertyChangeListener pcl)
	{
		support.addPropertyChangeListener(pcl); 
	} 
	public void removePropertyChangeListener(PropertyChangeListener pcl)
	{
		support.removePropertyChangeListener(pcl); 
	}

	public PropertyChangeSupport getSupport() {
		return support;
	}

	public void setSupport(PropertyChangeSupport support) {
		this.support = support;
	}

	public int getCustId() {
		return CustId;
	}

	public void setCustId(int custId) {
		CustId = custId;
	} 



}
