package components;

import java.util.ArrayList;

import javax.swing.JPanel;

import program.PostSystemPanel;

public class Memento 
{
	private int clock;
	private ArrayList<Package> Pack;
	private Customer[] Cust = new Customer[2];
	private  Hub h;
	private PostSystemPanel Panel; 
	private int counter;
	private int maxPac;
	
	public Memento(MainOffice state)
	{
		clock = state.getClock();
		h = new Hub(state.getHub());
		Pack = new ArrayList<Package>(state.getPackages());
		int i=0;
		for(Customer c : state.getCustomer())
		{
			Cust[i] = new Customer(c);
			i++;
		}
		counter = state.counter;
		//Panel = new PostSystemPanel(state.getPanel());
//		Panel.add(state.getPanel());
	}


	public int getClock() {
		return clock;
	}

	public void setClock(int clock) {
		this.clock = clock;
	}

	public ArrayList<Package> getPack() {
		return Pack;
	}

	public void setPack(ArrayList<Package> pack) {
		Pack = pack;
	}

	public Customer[] getCust() {
		return Cust;
	}
//
//	public void setCust(ArrayList<Customer> cust) {
//		Cust = cust;
//	}

	public Hub getH() {
		return h;
	}

	public void setH(Hub h) {
		this.h = h;
	}

	public PostSystemPanel getPanel() {
		return Panel;
	}

	public void setPanel(PostSystemPanel panel) {
		Panel = panel;
	}


	public int getCounter() {
		return counter;
	}


	public void setCounter(int counter) {
		this.counter = counter;
	}


	public int getMaxPac() {
		return maxPac;
	}


	public void setMaxPac(int maxPac) {
		this.maxPac = maxPac;
	}
	
	
	
}
