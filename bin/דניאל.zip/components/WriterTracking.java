package components;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;



public class WriterTracking {
	private static ReadWriteLock rw = new ReentrantReadWriteLock();
	private Lock read = rw.readLock();
	private Lock write = rw.writeLock();
	private static String FileName = "C:\\Users\\falfo\\eclipse-workspace\\H.M3\\src\\tracking.txt";
	private BufferedReader br;
	private BufferedWriter bw;
	private static int n = 1;
	private static final String pID =  "packageID=";
	static String s;

	public WriterTracking() 
	{
		//FileName = fn;
		try {
			//br = new BufferedReader(new FileReader(FileName));
			bw = new BufferedWriter(new FileWriter(FileName));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void Write(String Pid) {
		write.lock();
		try {
			bw = new BufferedWriter(new FileWriter(FileName , true));
			s = n + ". " +  Pid;
			bw.write(s);
			bw.newLine();
			n++;

			bw.newLine();
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

		write.unlock();
	}
	
	
	
	public static String getFileName() {
		return FileName;
	}

	public static void setFileName(String fileName) {
		FileName = fileName;
	}

	public static String GetTrackToWrite()
	{
		return s;
	}
}
