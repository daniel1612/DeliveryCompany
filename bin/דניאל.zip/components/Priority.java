package components;

public enum Priority {
	LOW, STANDARD, HIGHT
}
