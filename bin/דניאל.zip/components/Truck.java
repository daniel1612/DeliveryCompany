package components;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Random;

import javax.sound.midi.Track;

import program.PostSystemPanel;


public  abstract class Truck extends Observable implements Node,Runnable,Cloneable{
	private static int countID=2000;
	private int truckID;
	private String licensePlate;
	private String truckModel;
	private boolean available=true;
	private int timeLeft=0;
	private ArrayList<Package> packages=new ArrayList<Package>();
	protected int initTime;
	protected boolean threadSuspend = false;


	public Truck() {
		truckID=countID++;
		Random r= new Random();
		licensePlate=(r.nextInt(900)+100)+"-"+(r.nextInt(90)+10)+"-"+(r.nextInt(900)+100);
		truckModel="M"+r.nextInt(5);
		//addObserver(MainOffice.getInstance(initTime, truckID, null, countID));

	}

	public Truck(String licensePlate,String truckModel) {
		truckID=countID++;
		this.licensePlate=licensePlate;
		this.truckModel=truckModel;
	}

	
	public Truck(Truck other)
	{
		synchronized (this) 
		{
			this.available = other.available;
			this.initTime = other.initTime;
			this.licensePlate = new String(other.licensePlate);
			this.threadSuspend = other.threadSuspend;
			this.timeLeft = other.timeLeft;
			this.truckID = other.truckID;
			this.packages = new ArrayList<Package>(other.packages);
			this.truckModel = new String(other.truckModel);
			countID = other.getCountID();
		}

	}

	public ArrayList<Package> getPackages() {
		return packages;
	}


	public int getTimeLeft() {
		return timeLeft;
	}


	public void setTimeLeft(int timeLeft) {
		this.timeLeft = timeLeft;
	}


	@Override
	public String toString() {
		return "truckID=" + truckID + ", licensePlate=" + licensePlate + ", truckModel=" + truckModel + ", available= " + available ;
	}


	public static int getCountID() {
		return countID;
	}

	public static void setCountID(int countID) {
		Truck.countID = countID;
	}

	@Override
	public synchronized void collectPackage(Package p) {
		setAvailable(false);
		int time=(p.getSenderAddress().street%10+1)*10;
		this.setTimeLeft(time);
		this.initTime = time;
		this.packages.add(p);
		p.setStatus(Status.COLLECTION);
		Tracking tracking= new Tracking(MainOffice.getClock(), this, p.getStatus());
		p.addTracking(tracking);
		//notifyObservers(tracking.toString());
		System.out.println(getName() + " is collecting package " + p.getPackageID() + ", time to arrive: "+ getTimeLeft());
	}


	@Override
	public synchronized void deliverPackage(Package p) {}




	public Truck clone() {
		Truck clone = null;
		try {
			clone = (Truck)super.clone();


		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return clone;
	}	


	public void prototypeUpdate()
	{
		setTruckID(countID++);
		Random r= new Random();
		licensePlate=(r.nextInt(900)+100)+"-"+(r.nextInt(90)+10)+"-"+(r.nextInt(900)+100);
		truckModel="M"+r.nextInt(5);
		setTimeLeft(0);
		setAvailable(true);
		packages.clear();
	}


	public boolean isAvailable() {
		return available;
	}

	public void setTruckID(int truckid)
	{
		truckID=truckid;
	}

	public int getTruckID() {
		return truckID;
	}


	public void setAvailable(boolean available) {
		this.available = available;
	}


	public String getName() {
		return this.getClass().getSimpleName()+" "+ truckID;
	}

	public synchronized void setSuspend() {
		threadSuspend = true;
	}

	public synchronized void setResume() {
		threadSuspend = false;
		notify();
	}

	public abstract void paintComponent(Graphics g);

}
