package components;

import java.util.ArrayList;

public class CareTaker 
{
	private ArrayList<Memento> statesList;
	private int curState = -1;
	
	public CareTaker()
	{
		this.statesList = new ArrayList<>();
	}
	
	public void addMemento(Memento m) { 
		statesList.add(m); 
		curState = this.statesList.size() - 1;
	} 
	public Memento getMemento(int index) { 
		return statesList.get(index); 
	} 
	
	public Memento Undo()
	{
		System.out.println("Undoing state");
		if(this.curState <= 0)
		{
			curState = 0;
			return getMemento(curState);
		}
		
		curState--;
		return getMemento(curState);
	}

}
